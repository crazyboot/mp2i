See:
- https://discourse.jupyter.org/t/tip-speed-up-binder-launches-by-pulling-github-content-in-a-binder-link-with-nbgitpuller/922
- https://discourse.jupyter.org/t/how-to-reduce-mybinder-org-repository-startup-time/4956
